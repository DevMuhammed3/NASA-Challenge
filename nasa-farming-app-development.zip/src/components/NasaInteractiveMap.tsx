"use client";

import React, { useEffect, useRef, useState } from "react";
import {
  Layers,
  Crosshair,
  ExternalLink,
  Code2,
  Satellite,
  Thermometer,
  Droplets,
  Sprout,
  Compass,
  CheckCircle2,
  X,
} from "lucide-react";
import type LType from "leaflet";

export type NasaMapLayerMode = "ndvi" | "thermal" | "moisture" | "satellite";

interface NasaInteractiveMapProps {
  lat: number;
  lon: number;
  farmName: string;
  ndviIndex: number;
  avgTemp: number;
  soilMoistureRoot: number;
  soilPh: number;
  dataSourceStatus: string;
  rawNasaPayload: Record<string, unknown>;
  lang: "ar" | "en";
  onSelectCoordinates: (lat: number, lon: number) => void;
}

export function NasaInteractiveMap({
  lat,
  lon,
  farmName,
  ndviIndex,
  avgTemp,
  soilMoistureRoot,
  soilPh,
  dataSourceStatus,
  rawNasaPayload,
  lang,
  onSelectCoordinates,
}: NasaInteractiveMapProps) {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<LType.Map | null>(null);
  const leafletRef = useRef<typeof LType | null>(null);
  const overlayGroupRef = useRef<LType.LayerGroup | null>(null);
  const gibsLayerRef = useRef<LType.TileLayer | null>(null);

  const [activeLayer, setActiveLayer] = useState<NasaMapLayerMode>("ndvi");
  const [showRawModal, setShowRawModal] = useState(false);
  const [mapReady, setMapReady] = useState(false);

  // Initialize Leaflet map once on client
  useEffect(() => {
    let isMounted = true;

    async function initMap() {
      if (!mapContainerRef.current || mapInstanceRef.current) return;
      const L = (await import("leaflet")).default;
      if (!isMounted || !mapContainerRef.current) return;

      leafletRef.current = L;

      const map = L.map(mapContainerRef.current, {
        center: [lat, lon],
        zoom: 12,
        zoomControl: false,
        attributionControl: false,
      });

      L.control.zoom({ position: "bottomleft" }).addTo(map);

      // Base Layer: Esri World Imagery (Satellite)
      const satelliteBase = L.tileLayer(
        "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        {
          maxZoom: 18,
        }
      );
      satelliteBase.addTo(map);

      // Subtle dark reference labels overlay
      L.tileLayer(
        "https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}",
        {
          maxZoom: 18,
          opacity: 0.65,
        }
      ).addTo(map);

      const group = L.layerGroup().addTo(map);
      overlayGroupRef.current = group;

      map.on("click", (e: LType.LeafletMouseEvent) => {
        const clickedLat = Number(e.latlng.lat.toFixed(4));
        const clickedLon = Number(e.latlng.lng.toFixed(4));
        onSelectCoordinates(clickedLat, clickedLon);
      });

      mapInstanceRef.current = map;
      setMapReady(true);
    }

    initMap();

    return () => {
      isMounted = false;
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Update map center, NASA GIBS WMTS layer, and field polygon overlays when coordinates or activeLayer change
  useEffect(() => {
    const map = mapInstanceRef.current;
    const L = leafletRef.current;
    const group = overlayGroupRef.current;
    if (!map || !L || !group || !mapReady) return;

    map.setView([lat, lon], map.getZoom() < 9 ? 12 : map.getZoom(), {
      animate: true,
    });

    group.clearLayers();

    if (gibsLayerRef.current) {
      map.removeLayer(gibsLayerRef.current);
      gibsLayerRef.current = null;
    }

    // Add real NASA GIBS WMTS raster layer depending on activeLayer
    if (activeLayer === "ndvi") {
      const gibsNdvi = L.tileLayer(
        "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/MODIS_Terra_NDVI_8Day/default/2024-04-14/GoogleMapsCompatible_Level9/{z}/{y}/{x}.png",
        {
          maxNativeZoom: 9,
          maxZoom: 18,
          opacity: 0.42,
        }
      );
      gibsNdvi.addTo(map);
      gibsLayerRef.current = gibsNdvi;
    } else if (activeLayer === "thermal") {
      const gibsThermal = L.tileLayer(
        "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/MODIS_Terra_Land_Surface_Temp_Day/default/2024-04-14/GoogleMapsCompatible_Level7/{z}/{y}/{x}.png",
        {
          maxNativeZoom: 7,
          maxZoom: 18,
          opacity: 0.45,
        }
      );
      gibsThermal.addTo(map);
      gibsLayerRef.current = gibsThermal;
    }

    // Draw high-resolution Farm Parcel Boundary & Sub-Sector Telemetry Grid around (lat, lon)
    const d = 0.0085; // ~900m farm boundary radius
    const subSectors = [
      {
        bounds: [
          [lat, lon - d],
          [lat + d, lon - d],
          [lat + d, lon],
          [lat, lon],
        ] as [number, number][],
        zoneLabel: "Sector A (North-West)",
        delta: 0.04,
      },
      {
        bounds: [
          [lat, lon],
          [lat + d, lon],
          [lat + d, lon + d],
          [lat, lon + d],
        ] as [number, number][],
        zoneLabel: "Sector B (North-East)",
        delta: -0.02,
      },
      {
        bounds: [
          [lat - d, lon - d],
          [lat, lon - d],
          [lat, lon],
          [lat - d, lon],
        ] as [number, number][],
        zoneLabel: "Sector C (South-West)",
        delta: 0.02,
      },
      {
        bounds: [
          [lat - d, lon],
          [lat, lon],
          [lat, lon + d],
          [lat - d, lon + d],
        ] as [number, number][],
        zoneLabel: "Sector D (South-East)",
        delta: -0.05,
      },
    ];

    subSectors.forEach((sec) => {
      let fillColor = "#52B788";
      let fillOpacity = 0.38;

      if (activeLayer === "ndvi") {
        const localNdvi = ndviIndex + sec.delta;
        fillColor =
          localNdvi >= 0.6
            ? "#2D9A5E"
            : localNdvi >= 0.42
            ? "#74C69D"
            : "#E09F3E";
        fillOpacity = 0.42;
      } else if (activeLayer === "thermal") {
        const localTemp = avgTemp + sec.delta * 25;
        fillColor =
          localTemp >= 28
            ? "#D9534F"
            : localTemp >= 20
            ? "#E09F3E"
            : "#52B788";
        fillOpacity = 0.42;
      } else if (activeLayer === "moisture") {
        const localMoisture = soilMoistureRoot + sec.delta * 100;
        fillColor =
          localMoisture >= 58
            ? "#2E86AB"
            : localMoisture >= 42
            ? "#48CAE4"
            : "#E09F3E";
        fillOpacity = 0.42;
      } else {
        fillColor = "#9A7E3B";
        fillOpacity = 0.18;
      }

      L.polygon(sec.bounds, {
        color: "#D2CF9A",
        weight: 1.5,
        dashArray: "4 4",
        fillColor,
        fillOpacity,
      }).addTo(group);
    });

    // Outer Farm Perimeter Frame
    L.polygon(
      [
        [lat - d, lon - d],
        [lat + d, lon - d],
        [lat + d, lon + d],
        [lat - d, lon + d],
      ],
      {
        color: "#9A7E3B",
        weight: 3,
        fillOpacity: 0,
      }
    ).addTo(group);

    // Custom pulsing HTML pin marker at center of farm
    const customIcon = L.divIcon({
      className: "gaia-farm-marker",
      html: `
        <div style="position:relative;display:flex;align-items:center;justify-content:center;width:36px;height:36px;">
          <span style="position:absolute;width:36px;height:36px;border-radius:9999px;background:rgba(154,126,59,0.45);animation:ping 2s cubic-bezier(0,0,0.2,1) infinite;"></span>
          <div style="position:relative;width:22px;height:22px;border-radius:9999px;background:#9A7E3B;border:2.5px solid #D2CF9A;box-shadow:0 0 12px rgba(0,0,0,0.8);display:flex;align-items:center;justify-content:center;">
            <div style="width:6px;height:6px;border-radius:9999px;background:#28301C;"></div>
          </div>
        </div>
      `,
      iconSize: [36, 36],
      iconAnchor: [18, 18],
    });

    const marker = L.marker([lat, lon], { icon: customIcon }).addTo(group);
    marker.bindPopup(
      `<div style="background:#28301C;color:#D2CF9A;padding:8px 10px;border-radius:8px;border:1px solid #9A7E3B;font-family:sans-serif;min-width:190px;">
        <div style="font-weight:700;font-size:13px;margin-bottom:4px;color:#D2CF9A;">${farmName}</div>
        <div style="font-family:monospace;font-size:11px;color:#9FA37C;margin-bottom:6px;">${lat.toFixed(
          4
        )}°N, ${lon.toFixed(4)}°E</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;font-size:11px;">
          <span>NDVI: <strong style="color:#52B788;">${ndviIndex}</strong></span>
          <span>T2M: <strong style="color:#E09F3E;">${avgTemp}°C</strong></span>
          <span>GWET: <strong style="color:#48CAE4;">${soilMoistureRoot}%</strong></span>
          <span>pH: <strong style="color:#D2CF9A;">${soilPh}</strong></span>
        </div>
      </div>`,
      { closeButton: false }
    );
  }, [
    lat,
    lon,
    farmName,
    ndviIndex,
    avgTemp,
    soilMoistureRoot,
    soilPh,
    activeLayer,
    mapReady,
  ]);

  const nasaViewerUrl = `https://power.larc.nasa.gov/data-access-viewer/`;

  return (
    <div className="relative flex flex-col rounded-xl border border-[#435133] bg-[#323D25] overflow-hidden shadow-[0_10px_30px_-5px_rgba(0,0,0,0.45)]">
      {/* Top Map Control Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#435133] bg-[#28301C]/90 px-4 py-3">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#9A7E3B]/20 border border-[#9A7E3B]/50 text-[#D2CF9A]">
            <Satellite className="h-4 w-4 text-[#9A7E3B]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-[#D2CF9A]">
                {lang === "ar"
                  ? "خريطة ناسا التفاعلية ومستشعر الأقمار الصناعية (NASA GIBS & POWER)"
                  : "Interactive NASA GIBS & POWER Satellite Map"}
              </h3>
              <span className="inline-flex items-center gap-1 rounded-full bg-[#52B788]/20 border border-[#52B788]/40 px-2 py-0.5 text-[10px] font-mono text-[#52B788]">
                <CheckCircle2 className="h-3 w-3" />
                {dataSourceStatus === "NASA_LIVE"
                  ? "NASA POWER LIVE"
                  : "NASA AGRO-CLIMATOLOGY"}
              </span>
            </div>
            <p className="text-xs text-[#9FA37C]">
              {lang === "ar"
                ? "اضغط على أي نقطة في الخريطة لتحديد أرضك وسحب بيانات ناسا و SoilGrids فوراً"
                : "Click anywhere on the map to pin your field and fetch NASA & SoilGrids telemetry"}
            </p>
          </div>
        </div>

        {/* Layer Switcher Pills */}
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => setActiveLayer("ndvi")}
            className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-all ${
              activeLayer === "ndvi"
                ? "bg-[#9A7E3B] text-[#28301C] shadow-sm"
                : "bg-[#28301C] text-[#D2CF9A] hover:bg-[#435133]/60 border border-[#435133]"
            }`}
          >
            <Sprout className="h-3.5 w-3.5" />
            <span>{lang === "ar" ? "الغطاء النباتي NDVI" : "GIBS NDVI"}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveLayer("thermal")}
            className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-all ${
              activeLayer === "thermal"
                ? "bg-[#9A7E3B] text-[#28301C] shadow-sm"
                : "bg-[#28301C] text-[#D2CF9A] hover:bg-[#435133]/60 border border-[#435133]"
            }`}
          >
            <Thermometer className="h-3.5 w-3.5" />
            <span>{lang === "ar" ? "الحرارة T2M" : "Thermal T2M"}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveLayer("moisture")}
            className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-all ${
              activeLayer === "moisture"
                ? "bg-[#9A7E3B] text-[#28301C] shadow-sm"
                : "bg-[#28301C] text-[#D2CF9A] hover:bg-[#435133]/60 border border-[#435133]"
            }`}
          >
            <Droplets className="h-3.5 w-3.5" />
            <span>
              {lang === "ar" ? "رطوبة الجذور GWETROOT" : "Moisture GWET"}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveLayer("satellite")}
            className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-all ${
              activeLayer === "satellite"
                ? "bg-[#9A7E3B] text-[#28301C] shadow-sm"
                : "bg-[#28301C] text-[#D2CF9A] hover:bg-[#435133]/60 border border-[#435133]"
            }`}
          >
            <Layers className="h-3.5 w-3.5" />
            <span>{lang === "ar" ? "قمر صناعي" : "Satellite"}</span>
          </button>
        </div>
      </div>

      {/* Map Canvas Viewport */}
      <div className="relative h-[390px] w-full bg-[#1E2515]">
        <div ref={mapContainerRef} className="h-full w-full z-10" />

        {/* Floating Coordinate Telemetry HUD (Top-Right) */}
        <div
          dir="ltr"
          className="pointer-events-none absolute top-3 right-3 z-20 flex flex-col gap-1.5 rounded-xl border border-[#9A7E3B]/50 bg-[#28301C]/90 px-3 py-2.5 backdrop-blur-md shadow-lg"
        >
          <div className="flex items-center gap-2 text-[11px] font-mono text-[#9FA37C]">
            <Crosshair className="h-3.5 w-3.5 text-[#9A7E3B]" />
            <span>TARGET TELEMETRY LOCK</span>
          </div>
          <div className="flex items-center gap-3 text-xs font-mono font-bold text-[#D2CF9A]">
            <span>LAT: {lat.toFixed(4)}°N</span>
            <span className="text-[#9A7E3B]">|</span>
            <span>LON: {lon.toFixed(4)}°E</span>
          </div>
          <div className="flex items-center justify-between gap-2 border-t border-[#435133] pt-1.5 text-[11px] font-mono">
            <span className="text-[#52B788]">NDVI: {ndviIndex}</span>
            <span className="text-[#E09F3E]">T2M: {avgTemp}°C</span>
            <span className="text-[#48CAE4]">GWET: {soilMoistureRoot}%</span>
          </div>
        </div>

        {/* Floating Active Layer Legend (Bottom-Right) */}
        <div className="pointer-events-none absolute bottom-3 right-3 z-20 rounded-xl border border-[#435133] bg-[#28301C]/90 px-3 py-2 backdrop-blur-md shadow-lg">
          {activeLayer === "ndvi" && (
            <div className="flex items-center gap-2 text-xs">
              <span className="font-semibold text-[#D2CF9A]">
                {lang === "ar"
                  ? "مؤشر الغطاء النباتي (MODIS NDVI):"
                  : "MODIS NDVI Vigor:"}
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] text-[#E09F3E]">
                <span className="h-2.5 w-2.5 rounded-sm bg-[#E09F3E]" /> 0.2
                (ضعيف)
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] text-[#74C69D]">
                <span className="h-2.5 w-2.5 rounded-sm bg-[#74C69D]" /> 0.5
                (متوسط)
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] text-[#2D9A5E]">
                <span className="h-2.5 w-2.5 rounded-sm bg-[#2D9A5E]" /> 0.75+
                (كثيف)
              </span>
            </div>
          )}
          {activeLayer === "thermal" && (
            <div className="flex items-center gap-2 text-xs">
              <span className="font-semibold text-[#D2CF9A]">
                {lang === "ar"
                  ? "توزيع الحرارة السطحية (NASA T2M):"
                  : "Surface Thermal (T2M):"}
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] text-[#52B788]">
                <span className="h-2.5 w-2.5 rounded-sm bg-[#52B788]" /> &lt;20°C
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] text-[#E09F3E]">
                <span className="h-2.5 w-2.5 rounded-sm bg-[#E09F3E]" /> 20–28°C
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] text-[#D9534F]">
                <span className="h-2.5 w-2.5 rounded-sm bg-[#D9534F]" /> &gt;28°C
              </span>
            </div>
          )}
          {activeLayer === "moisture" && (
            <div className="flex items-center gap-2 text-xs">
              <span className="font-semibold text-[#D2CF9A]">
                {lang === "ar"
                  ? "رطوبة الجذور (NASA GWETROOT):"
                  : "Root Wetness (GWETROOT):"}
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] text-[#E09F3E]">
                <span className="h-2.5 w-2.5 rounded-sm bg-[#E09F3E]" /> &lt;40%
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] text-[#48CAE4]">
                <span className="h-2.5 w-2.5 rounded-sm bg-[#48CAE4]" /> 40–60%
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] text-[#2E86AB]">
                <span className="h-2.5 w-2.5 rounded-sm bg-[#2E86AB]" /> &gt;60%
              </span>
            </div>
          )}
          {activeLayer === "satellite" && (
            <div className="flex items-center gap-2 text-xs text-[#D2CF9A]">
              <Compass className="h-3.5 w-3.5 text-[#9A7E3B]" />
              <span>
                {lang === "ar"
                  ? "مضلع حدود المزرعة (4 قطاعات تحليلية)"
                  : "4-Sector Farm Parcel Boundary"}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Bar: NASA POWER Data Access Viewer Link & Raw API Payload Inspector */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-[#435133] bg-[#28301C] px-4 py-2.5 text-xs">
        <div className="flex items-center gap-2 text-[#9FA37C]">
          <span className="inline-block h-2 w-2 rounded-full bg-[#9A7E3B]" />
          <span>
            {lang === "ar"
              ? "مصدر الطبقات: NASA GIBS WMTS + NASA POWER Agroclimatology + ISRIC SoilGrids"
              : "Sources: NASA GIBS WMTS + NASA POWER Agroclimatology + ISRIC SoilGrids"}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowRawModal(true)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#435133] bg-[#323D25] px-2.5 py-1 text-xs font-medium text-[#D2CF9A] hover:border-[#9A7E3B] transition-colors"
          >
            <Code2 className="h-3.5 w-3.5 text-[#9A7E3B]" />
            <span>
              {lang === "ar"
                ? "فحص بيانات NASA POWER الخام (JSON)"
                : "Inspect Raw NASA JSON"}
            </span>
          </button>

          <a
            href={nasaViewerUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 rounded-lg bg-[#9A7E3B]/20 border border-[#9A7E3B] px-2.5 py-1 text-xs font-semibold text-[#D2CF9A] hover:bg-[#9A7E3B] hover:text-[#28301C] transition-colors"
          >
            <ExternalLink className="h-3.5 w-3.5" />
            <span>NASA POWER Data Access Viewer</span>
          </a>
        </div>
      </div>

      {/* Raw NASA POWER Payload Modal */}
      {showRawModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm">
          <div className="flex max-h-[82vh] w-full max-w-2xl flex-col rounded-2xl border border-[#9A7E3B] bg-[#28301C] shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between border-b border-[#435133] bg-[#323D25] px-5 py-3.5">
              <div className="flex items-center gap-2">
                <Code2 className="h-5 w-5 text-[#9A7E3B]" />
                <h4 className="font-bold text-[#D2CF9A]">
                  {lang === "ar"
                    ? "بيانات الاستشعار الخام من NASA POWER & SoilGrids"
                    : "Raw NASA POWER & SoilGrids Telemetry Payload"}
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setShowRawModal(false)}
                className="rounded-lg p-1 text-[#9FA37C] hover:bg-[#28301C] hover:text-[#D2CF9A]"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="overflow-y-auto p-5 space-y-3 text-xs">
              <div className="rounded-lg border border-[#435133] bg-[#323D25] p-3 text-[#D2CF9A]">
                <p className="mb-1 font-semibold text-[#9A7E3B]">
                  {lang === "ar"
                    ? "الرابط المباشر لـ NASA POWER Data Access Viewer:"
                    : "Direct NASA POWER Data Access Viewer Portal:"}
                </p>
                <a
                  href={nasaViewerUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  dir="ltr"
                  className="inline-flex items-center gap-1 font-mono text-xs underline text-[#52B788]"
                >
                  https://power.larc.nasa.gov/data-access-viewer/
                  <ExternalLink className="h-3 w-3" />
                </a>
                <p className="mt-1 text-[11px] text-[#9FA37C]" dir="ltr">
                  Selected Point: Lat {lat.toFixed(4)}, Lon {lon.toFixed(4)} |
                  Community: AG (Agroclimatology) | Parameters: T2M, T2M_MAX,
                  T2M_MIN, RH2M, PRECTOTCORR, GWETTOP, GWETROOT,
                  ALLSKY_SFC_SW_DWN
                </p>
              </div>
              <pre
                dir="ltr"
                className="overflow-x-auto rounded-xl border border-[#435133] bg-[#1A2012] p-4 font-mono text-[11px] leading-relaxed text-[#D2CF9A]"
              >
                {JSON.stringify(rawNasaPayload, null, 2)}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
