"use client";

import React from "react";

interface GaiaLogoProps {
  size?: number;
  className?: string;
  showBadge?: boolean;
}

export function GaiaLogo({
  size = 44,
  className = "",
  showBadge = false,
}: GaiaLogoProps) {
  return (
    <div className={`relative inline-flex items-center justify-center ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 64 64"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="drop-shadow-[0_2px_10px_rgba(154,126,59,0.35)]"
      >
        {/* Outer Orbital Ring */}
        <circle
          cx="32"
          cy="32"
          r="30"
          fill="#28301C"
          stroke="url(#gaiaGoldGrad)"
          strokeWidth="2.2"
        />
        <circle
          cx="32"
          cy="32"
          r="25.5"
          stroke="#D2CF9A"
          strokeOpacity="0.22"
          strokeWidth="1"
          strokeDasharray="3 3"
        />

        {/* Satellite Orbit Arc */}
        <path
          d="M11 24C18 12 46 12 53 24"
          stroke="#9A7E3B"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeOpacity="0.65"
        />
        <circle cx="49" cy="18" r="2.3" fill="#D2CF9A" />

        {/* Stylized Human/Goddess Mind + Botanical Leaf Silhouette (GAIA) */}
        <path
          d="M22 46C20 39 21 30 27 24C33 18 43 17 47 17C47 25 44 34 37 40C31 45 25 46 22 46Z"
          fill="url(#gaiaLeafGrad)"
          stroke="#D2CF9A"
          strokeWidth="1.5"
          strokeLinejoin="round"
        />

        {/* Secondary Sprout Leaf */}
        <path
          d="M22 46C17 42 15 35 17 29C21 31 24 36 24 42"
          fill="#323D25"
          stroke="#9A7E3B"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Central Neural / Leaf Vein */}
        <path
          d="M21 47C26 41 32 34 42 22"
          stroke="#D2CF9A"
          strokeWidth="1.8"
          strokeLinecap="round"
        />
        <path
          d="M29 37L36 36M33 31L40 30M26 41L25 34"
          stroke="#D2CF9A"
          strokeWidth="1.3"
          strokeLinecap="round"
          strokeOpacity="0.85"
        />

        {/* Root Horizon Lines */}
        <path
          d="M16 50C24 47 40 47 48 50"
          stroke="#9A7E3B"
          strokeWidth="1.8"
          strokeLinecap="round"
        />
        <path
          d="M21 54C28 52 36 52 43 54"
          stroke="#D2CF9A"
          strokeWidth="1.2"
          strokeLinecap="round"
          strokeOpacity="0.6"
        />

        <defs>
          <linearGradient
            id="gaiaGoldGrad"
            x1="4"
            y1="4"
            x2="60"
            y2="60"
            gradientUnits="userSpaceOnUse"
          >
            <stop stopColor="#D2CF9A" />
            <stop offset="0.5" stopColor="#9A7E3B" />
            <stop offset="1" stopColor="#435133" />
          </linearGradient>
          <linearGradient
            id="gaiaLeafGrad"
            x1="20"
            y1="17"
            x2="47"
            y2="46"
            gradientUnits="userSpaceOnUse"
          >
            <stop stopColor="#9A7E3B" />
            <stop offset="0.6" stopColor="#323D25" />
            <stop offset="1" stopColor="#28301C" />
          </linearGradient>
        </defs>
      </svg>
      {showBadge && (
        <span className="absolute -bottom-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-[#52B788] text-[9px] font-bold text-[#28301C] ring-2 ring-[#28301C]">
          AI
        </span>
      )}
    </div>
  );
}
