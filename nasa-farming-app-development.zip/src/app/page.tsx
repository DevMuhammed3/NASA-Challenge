"use client";

import React, { useState, useEffect, useCallback } from "react";
import {
  Thermometer,
  Droplets,
  FlaskConical,
  CloudRain,
  Compass,
  Sparkles,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Sprout,
  ArrowLeftRight,
  Layers,
  MapPin,
  Database,
  History,
  Trash2,
  ExternalLink,
  TrendingUp,
  ShieldAlert,
  Info,
  Award,
  Globe,
  Calendar,
} from "lucide-react";
import { GaiaLogo } from "@/components/GaiaLogo";
import { NasaInteractiveMap } from "@/components/NasaInteractiveMap";
import {
  GaiaChatbotDrawer,
  type ActiveAnalysisForChat,
} from "@/components/GaiaChatbotDrawer";
import { FARM_PRESETS, INITIAL_CROPS_SEED } from "@/lib/gaia-engine";
import type {
  CropSuitabilityResult,
  MonthForecastItem,
  RotationSeasonStep,
  ClimateAlertItem,
} from "@/db/schema";

interface SavedFarmAnalysis {
  id: number;
  farmName: string;
  regionName: string;
  latitude: number;
  longitude: number;
  areaFeddans: number;
  previousCropCode: string | null;
  avgTemp3Mo: number;
  maxTemp3Mo: number;
  minTemp3Mo: number;
  relativeHumidity: number;
  soilPh: number;
  totalPrecip3Mo: number;
  soilMoistureSurface: number;
  soilMoistureRoot: number;
  solarRadiation: number;
  ndviIndex: number;
  soilTextureAr: string;
  soilTextureEn: string;
  organicCarbonGkg: number;
  salinityEc: number;
  dataSourceStatus: string;
  forecast3Months: MonthForecastItem[];
  recommendations: CropSuitabilityResult[];
  rotationPlan: RotationSeasonStep[];
  climateAlerts: ClimateAlertItem[];
  rawNasaPayload: Record<string, unknown>;
  createdAt: string;
}

type ActiveTab = "dashboard" | "suitability" | "rotation" | "knowledge";

export default function GaiaSmartAgricultureApp() {
  const [lang, setLang] = useState<"ar" | "en">("ar");
  const [activeTab, setActiveTab] = useState<ActiveTab>("dashboard");

  // Form state for field analysis
  const [latInput, setLatInput] = useState<string>("31.1107");
  const [lonInput, setLonInput] = useState<string>("30.9388");
  const [farmNameInput, setFarmNameInput] = useState<string>(
    "مزرعة دلتا النيل النموذجية"
  );
  const [areaFeddansInput, setAreaFeddansInput] = useState<string>("15");
  const [previousCropInput, setPreviousCropInput] = useState<string>("clover");

  // Active analysis & saved history state
  const [activeAnalysis, setActiveAnalysis] =
    useState<SavedFarmAnalysis | null>(null);
  const [savedAnalyses, setSavedAnalyses] = useState<SavedFarmAnalysis[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [loadingStage, setLoadingStage] = useState<string>("");
  const [selectedCropDetail, setSelectedCropDetail] =
    useState<CropSuitabilityResult | null>(null);
  const [chatPromptTrigger, setChatPromptTrigger] = useState<{
    text: string;
    timestamp: number;
  } | null>(null);

  // Load initial seeded analyses from PostgreSQL on mount
  const fetchInitialData = useCallback(async () => {
    try {
      const res = await fetch("/api/analyze");
      const data = await res.json();
      if (data.status === "Success" && Array.isArray(data.analyses)) {
        setSavedAnalyses(data.analyses);
        if (data.analyses.length > 0) {
          const first = data.analyses[0] as SavedFarmAnalysis;
          setActiveAnalysis(first);
          setLatInput(String(first.latitude));
          setLonInput(String(first.longitude));
          setFarmNameInput(first.farmName);
          setAreaFeddansInput(String(first.areaFeddans));
          setPreviousCropInput(first.previousCropCode || "clover");
          setSelectedCropDetail(first.recommendations?.[0] || null);
        }
      }
    } catch (err) {
      console.error("Failed to fetch initial analyses:", err);
    }
  }, []);

  useEffect(() => {
    fetchInitialData();
  }, [fetchInitialData]);

  // Trigger full NASA POWER + SoilGrids + Suitability + Rotation analysis
  async function handleRunFieldAnalysis(customCoords?: {
    lat: number;
    lon: number;
    farmName?: string;
    regionName?: string;
    previousCrop?: string;
  }) {
    const targetLat = customCoords ? customCoords.lat : Number(latInput);
    const targetLon = customCoords ? customCoords.lon : Number(lonInput);
    const targetName =
      customCoords?.farmName ??
      (farmNameInput.trim() ||
        `مزرعة (${targetLat.toFixed(3)}°N, ${targetLon.toFixed(3)}°E)`);
    const targetPrevCrop = customCoords?.previousCrop ?? previousCropInput;

    if (Number.isNaN(targetLat) || Number.isNaN(targetLon)) return;

    setIsAnalyzing(true);
    setLoadingStage(
      lang === "ar"
        ? "جاري الاتصال بـ NASA POWER API لسحب التوقعات المناخية لـ 3 أشهر..."
        : "Connecting to NASA POWER API for 3-month agroclimatology..."
    );

    const stageTimer1 = setTimeout(() => {
      setLoadingStage(
        lang === "ar"
          ? "جاري سحب درجة قلوية التربة (pH) من SoilGrids ومرئيات NASA GIBS NDVI..."
          : "Querying SoilGrids pH H2O & NASA GIBS MODIS NDVI..."
      );
    }, 450);

    const stageTimer2 = setTimeout(() => {
      setLoadingStage(
        lang === "ar"
          ? "جاري تشغيل خوارزمية الملاءمة الموزونة ومحرك تدوير المحاصيل..."
          : "Running Weighted Suitability & 3-Season Crop Rotation Engine..."
      );
    }, 900);

    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          lat: targetLat,
          lon: targetLon,
          farmName: targetName,
          regionName: customCoords?.regionName,
          areaFeddans: Number(areaFeddansInput) || 15,
          previousCropCode: targetPrevCrop || null,
        }),
      });

      const data = await res.json();
      if (data.status === "Success" && data.analysis) {
        setActiveAnalysis(data.analysis);
        setSelectedCropDetail(data.analysis.recommendations?.[0] || null);
        if (Array.isArray(data.analyses)) {
          setSavedAnalyses(data.analyses);
        }
      }
    } catch (error) {
      console.error("Analysis error:", error);
    } finally {
      clearTimeout(stageTimer1);
      clearTimeout(stageTimer2);
      setIsAnalyzing(false);
      setLoadingStage("");
    }
  }

  // Handle preset selection
  function handleSelectPreset(presetId: string) {
    const preset = FARM_PRESETS.find((p) => p.id === presetId);
    if (!preset) return;
    const nameToUse = lang === "ar" ? preset.nameAr : preset.nameEn;
    setLatInput(String(preset.lat));
    setLonInput(String(preset.lon));
    setFarmNameInput(nameToUse);
    setPreviousCropInput(preset.defaultPreviousCrop);

    handleRunFieldAnalysis({
      lat: preset.lat,
      lon: preset.lon,
      farmName: nameToUse,
      regionName: lang === "ar" ? preset.regionAr : preset.regionEn,
      previousCrop: preset.defaultPreviousCrop,
    });
  }

  // Handle map click coordinate selection
  function handleMapClickCoordinates(clickedLat: number, clickedLon: number) {
    setLatInput(String(clickedLat));
    setLonInput(String(clickedLon));
    const autoName =
      lang === "ar"
        ? `أرض زراعية (${clickedLat.toFixed(3)}°N, ${clickedLon.toFixed(3)}°E)`
        : `Field Parcel (${clickedLat.toFixed(3)}°N, ${clickedLon.toFixed(3)}°E)`;
    setFarmNameInput(autoName);

    handleRunFieldAnalysis({
      lat: clickedLat,
      lon: clickedLon,
      farmName: autoName,
    });
  }

  async function handleDeleteSavedAnalysis(id: number, e: React.MouseEvent) {
    e.stopPropagation();
    try {
      const res = await fetch(`/api/analyze?id=${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.status === "Success" && Array.isArray(data.analyses)) {
        setSavedAnalyses(data.analyses);
        if (activeAnalysis?.id === id && data.analyses.length > 0) {
          setActiveAnalysis(data.analyses[0]);
        }
      }
    } catch (err) {
      console.error("Delete error:", err);
    }
  }

  const topRecommendation = activeAnalysis?.recommendations?.[0];
  const phPercentageOnBar = activeAnalysis
    ? Math.max(
        5,
        Math.min(95, ((activeAnalysis.soilPh - 4.5) / (9.0 - 4.5)) * 100)
      )
    : 60;

  return (
    <div
      dir={lang === "ar" ? "rtl" : "ltr"}
      className="min-h-screen bg-[#28301C] text-[#D2CF9A] pb-24"
    >
      {/* Top Navigation & Brand Header */}
      <header className="sticky top-0 z-30 border-b border-[#435133] bg-[#28301C]/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-[1440px] flex-wrap items-center justify-between gap-4 px-4 py-3 sm:px-6">
          {/* Brand Logo + Title */}
          <div className="flex items-center gap-3">
            <GaiaLogo size={46} />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-extrabold tracking-tight text-[#D2CF9A] sm:text-xl">
                  GAIA
                </h1>
                <span className="rounded-md bg-[#9A7E3B]/25 border border-[#9A7E3B] px-2 py-0.5 text-[11px] font-mono font-bold text-[#D2CF9A]">
                  NASA SPACE APPS 2026
                </span>
              </div>
              <p className="text-xs text-[#9FA37C]">
                {lang === "ar"
                  ? "نظام دعم القرار الزراعي الذكي وتدوير المحاصيل ببيانات ناسا (Adapting Farms with NASA Data)"
                  : "Smart Agricultural Decision Support & Crop Rotation via NASA Earth Data"}
              </p>
            </div>
          </div>

          {/* Navigation View Tabs */}
          <nav className="flex flex-wrap items-center gap-1.5 rounded-xl border border-[#435133] bg-[#323D25] p-1">
            <button
              type="button"
              onClick={() => setActiveTab("dashboard")}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition-all ${
                activeTab === "dashboard"
                  ? "bg-[#9A7E3B] text-[#28301C] shadow-sm"
                  : "text-[#D2CF9A] hover:bg-[#28301C]/60"
              }`}
            >
              <Compass className="h-3.5 w-3.5" />
              <span>
                {lang === "ar"
                  ? "لوحة التحكم وخرائط ناسا"
                  : "Dashboard & NASA Map"}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("suitability")}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition-all ${
                activeTab === "suitability"
                  ? "bg-[#9A7E3B] text-[#28301C] shadow-sm"
                  : "text-[#D2CF9A] hover:bg-[#28301C]/60"
              }`}
            >
              <Award className="h-3.5 w-3.5" />
              <span>
                {lang === "ar"
                  ? "تحليل ملاءمة المحاصيل (10)"
                  : "Crop Suitability (10)"}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("rotation")}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition-all ${
                activeTab === "rotation"
                  ? "bg-[#9A7E3B] text-[#28301C] shadow-sm"
                  : "text-[#D2CF9A] hover:bg-[#28301C]/60"
              }`}
            >
              <ArrowLeftRight className="h-3.5 w-3.5" />
              <span>
                {lang === "ar"
                  ? "محرك تدوير المحاصيل"
                  : "Crop Rotation Planner"}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("knowledge")}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition-all ${
                activeTab === "knowledge"
                  ? "bg-[#9A7E3B] text-[#28301C] shadow-sm"
                  : "text-[#D2CF9A] hover:bg-[#28301C]/60"
              }`}
            >
              <Database className="h-3.5 w-3.5" />
              <span>
                {lang === "ar"
                  ? "قاعدة بيانات المحاصيل والخوارزمية"
                  : "Crop DB & Algorithm"}
              </span>
            </button>
          </nav>

          {/* Language Toggle & NASA Viewer Shortcut */}
          <div className="flex items-center gap-2">
            <a
              href="https://www.spaceappschallenge.org/2026/challenges/adapting-farms-with-nasa-data/?tab=resources"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden xl:inline-flex items-center gap-1.5 rounded-lg border border-[#435133] bg-[#323D25] px-2.5 py-1.5 text-xs font-medium text-[#D2CF9A] hover:border-[#9A7E3B] transition-colors"
            >
              <ExternalLink className="h-3.5 w-3.5 text-[#9A7E3B]" />
              <span>NASA Challenge Resources</span>
            </a>

            <button
              type="button"
              onClick={() => setLang(lang === "ar" ? "en" : "ar")}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#9A7E3B] bg-[#323D25] px-3 py-1.5 text-xs font-bold text-[#D2CF9A] hover:bg-[#9A7E3B] hover:text-[#28301C] transition-colors"
            >
              <Globe className="h-3.5 w-3.5" />
              <span>{lang === "ar" ? "English (EN)" : "العربية (AR)"}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="mx-auto max-w-[1440px] px-4 pt-6 sm:px-6 space-y-6">
        {/* Welcome Banner & 4 Core NASA Telemetry KPI Cards (Points 1, 2, 3, 4) */}
        <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {/* KPI 1: 3-Month Expected Temperature (NASA POWER T2M) */}
          <div className="relative overflow-hidden rounded-xl border border-[#435133] bg-[#323D25] p-5 shadow-[0_10px_30px_-5px_rgba(0,0,0,0.4)]">
            <div className="flex items-start justify-between">
              <div>
                <span className="inline-flex items-center gap-1 rounded-md bg-[#28301C] px-2 py-0.5 font-mono text-[10px] font-semibold text-[#9A7E3B]">
                  1. NASA POWER • T2M
                </span>
                <h2 className="mt-1.5 text-xs font-semibold text-[#9FA37C]">
                  {lang === "ar"
                    ? "درجة الحرارة المتوقعة (3 أشهر)"
                    : "3-Month Expected Temperature"}
                </h2>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#28301C] border border-[#435133] text-[#E09F3E]">
                <Thermometer className="h-5 w-5" />
              </div>
            </div>

            <div className="mt-3 flex items-baseline gap-2" dir="ltr">
              <span className="font-mono text-3xl font-extrabold text-[#D2CF9A]">
                {activeAnalysis ? `${activeAnalysis.avgTemp3Mo}°C` : "21.4°C"}
              </span>
              <span className="font-mono text-xs text-[#52B788]">
                ({activeAnalysis?.minTemp3Mo ?? 14.8}° –{" "}
                {activeAnalysis?.maxTemp3Mo ?? 28.2}°C)
              </span>
            </div>

            <div className="mt-3">
              <div className="flex justify-between text-[11px] text-[#9FA37C] mb-1">
                <span>
                  {lang === "ar"
                    ? "مؤشر اعتدال الموسم الزراعي"
                    : "Seasonal Thermal Index"}
                </span>
                <span className="font-mono text-[#D2CF9A]">
                  {activeAnalysis && activeAnalysis.avgTemp3Mo <= 28
                    ? "Optimal"
                    : "Warm"}
                </span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-[#28301C]">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#52B788] via-[#9A7E3B] to-[#E09F3E]"
                  style={{
                    width: `${Math.min(
                      100,
                      Math.max(20, ((activeAnalysis?.avgTemp3Mo ?? 21) / 38) * 100)
                    )}%`,
                  }}
                />
              </div>
            </div>
          </div>

          {/* KPI 2: Atmospheric Humidity & Root Soil Moisture (RH2M & GWETROOT) */}
          <div className="relative overflow-hidden rounded-xl border border-[#435133] bg-[#323D25] p-5 shadow-[0_10px_30px_-5px_rgba(0,0,0,0.4)]">
            <div className="flex items-start justify-between">
              <div>
                <span className="inline-flex items-center gap-1 rounded-md bg-[#28301C] px-2 py-0.5 font-mono text-[10px] font-semibold text-[#9A7E3B]">
                  2. NASA POWER • RH2M & GWETROOT
                </span>
                <h2 className="mt-1.5 text-xs font-semibold text-[#9FA37C]">
                  {lang === "ar"
                    ? "نسبة الرطوبة في الجو ومنطقة الجذور"
                    : "Atmospheric & Root-Zone Humidity"}
                </h2>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#28301C] border border-[#435133] text-[#48CAE4]">
                <Droplets className="h-5 w-5" />
              </div>
            </div>

            <div className="mt-3 flex items-baseline gap-2.5" dir="ltr">
              <span className="font-mono text-3xl font-extrabold text-[#D2CF9A]">
                {activeAnalysis
                  ? `${activeAnalysis.relativeHumidity}%`
                  : "58.2%"}
              </span>
              <span className="font-mono text-xs text-[#48CAE4]">
                GWETROOT: {activeAnalysis?.soilMoistureRoot ?? 61.5}%
              </span>
            </div>

            <div className="mt-3">
              <div className="flex justify-between text-[11px] text-[#9FA37C] mb-1">
                <span>
                  {lang === "ar"
                    ? `رطوبة التربة السطحية (GWETTOP: ${
                        activeAnalysis?.soilMoistureSurface ?? 56
                      }%)`
                    : `Topsoil Wetness (GWETTOP: ${
                        activeAnalysis?.soilMoistureSurface ?? 56
                      }%)`}
                </span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-[#28301C]">
                <div
                  className="h-full rounded-full bg-[#52B788]"
                  style={{
                    width: `${Math.min(
                      100,
                      activeAnalysis?.relativeHumidity ?? 58
                    )}%`,
                  }}
                />
              </div>
            </div>
          </div>

          {/* KPI 3: Soil Alkalinity / Acidity (SoilGrids pH H2O) */}
          <div className="relative overflow-hidden rounded-xl border border-[#435133] bg-[#323D25] p-5 shadow-[0_10px_30px_-5px_rgba(0,0,0,0.4)]">
            <div className="flex items-start justify-between">
              <div>
                <span className="inline-flex items-center gap-1 rounded-md bg-[#28301C] px-2 py-0.5 font-mono text-[10px] font-semibold text-[#9A7E3B]">
                  3. SOILGRIDS v2.0 • pH H2O
                </span>
                <h2 className="mt-1.5 text-xs font-semibold text-[#9FA37C]">
                  {lang === "ar"
                    ? "درجة قلوية / حموضة التربة (pH)"
                    : "Soil Alkalinity / Acidity (pH)"}
                </h2>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#28301C] border border-[#435133] text-[#9A7E3B]">
                <FlaskConical className="h-5 w-5" />
              </div>
            </div>

            <div className="mt-3 flex items-baseline gap-2.5" dir="ltr">
              <span className="font-mono text-3xl font-extrabold text-[#D2CF9A]">
                {activeAnalysis ? activeAnalysis.soilPh : "7.25"}
              </span>
              <span
                className={`rounded-md px-2 py-0.5 text-[11px] font-bold ${
                  (activeAnalysis?.soilPh ?? 7.2) >= 7.65
                    ? "bg-[#E09F3E]/20 text-[#E09F3E]"
                    : "bg-[#52B788]/20 text-[#52B788]"
                }`}
              >
                {(activeAnalysis?.soilPh ?? 7.2) >= 7.65
                  ? lang === "ar"
                    ? "تميل للقلوية"
                    : "Alkaline"
                  : lang === "ar"
                  ? "متوازنة (مثالية)"
                  : "Optimal Neutral"}
              </span>
            </div>

            {/* Visual pH Spectrum Scale Bar */}
            <div className="mt-3">
              <div
                dir="ltr"
                className="flex justify-between font-mono text-[10px] text-[#9FA37C] mb-1"
              >
                <span>4.5 Acid</span>
                <span>7.0 Neutral</span>
                <span>9.0 Alkaline</span>
              </div>
              <div className="relative h-2.5 w-full rounded-full bg-gradient-to-r from-[#E09F3E] via-[#52B788] to-[#9A7E3B]">
                <div
                  className="absolute -top-1 h-4 w-2 -translate-x-1/2 rounded-sm border border-[#28301C] bg-[#D2CF9A] shadow"
                  style={{ left: `${phPercentageOnBar}%` }}
                />
              </div>
            </div>
          </div>

          {/* KPI 4: 3-Month Precipitation & Satellite NDVI (PRECTOTCORR & GIBS NDVI) */}
          <div className="relative overflow-hidden rounded-xl border border-[#435133] bg-[#323D25] p-5 shadow-[0_10px_30px_-5px_rgba(0,0,0,0.4)]">
            <div className="flex items-start justify-between">
              <div>
                <span className="inline-flex items-center gap-1 rounded-md bg-[#28301C] px-2 py-0.5 font-mono text-[10px] font-semibold text-[#9A7E3B]">
                  4. PRECTOTCORR & GIBS NDVI
                </span>
                <h2 className="mt-1.5 text-xs font-semibold text-[#9FA37C]">
                  {lang === "ar"
                    ? "الأمطار المتوقعة (3 أشهر) والغطاء النباتي"
                    : "3-Mo Precipitation & MODIS NDVI"}
                </h2>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#28301C] border border-[#435133] text-[#52B788]">
                <CloudRain className="h-5 w-5" />
              </div>
            </div>

            <div className="mt-3 flex items-baseline gap-2.5" dir="ltr">
              <span className="font-mono text-3xl font-extrabold text-[#D2CF9A]">
                {activeAnalysis
                  ? `${activeAnalysis.totalPrecip3Mo} mm`
                  : "28.4 mm"}
              </span>
              <span className="font-mono text-xs text-[#52B788]">
                NDVI: {activeAnalysis?.ndviIndex ?? 0.68}
              </span>
            </div>

            <div className="mt-3">
              <div className="flex justify-between text-[11px] text-[#9FA37C] mb-1">
                <span>
                  {lang === "ar"
                    ? `الإشعاع الشمسي: ${
                        activeAnalysis?.solarRadiation ?? 5.8
                      } kWh/m²/d`
                    : `Solar Flux: ${
                        activeAnalysis?.solarRadiation ?? 5.8
                      } kWh/m²/d`}
                </span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-[#28301C]">
                <div
                  className="h-full rounded-full bg-[#9A7E3B]"
                  style={{
                    width: `${Math.min(
                      100,
                      (activeAnalysis?.ndviIndex ?? 0.68) * 100
                    )}%`,
                  }}
                />
              </div>
            </div>
          </div>
        </section>

        {/* Loading Banner when Fetching NASA & SoilGrids Data */}
        {isAnalyzing && (
          <div className="flex items-center justify-between rounded-xl border border-[#9A7E3B] bg-[#323D25] px-5 py-3.5 shadow-lg">
            <div className="flex items-center gap-3">
              <RefreshCw className="h-5 w-5 animate-spin text-[#9A7E3B]" />
              <div>
                <div className="text-sm font-bold text-[#D2CF9A]">
                  {loadingStage}
                </div>
                <div className="text-xs text-[#9FA37C]" dir="ltr">
                  Targets: power.larc.nasa.gov/api/temporal/climatology/point •
                  rest.isric.org/soilgrids/v2.0
                </div>
              </div>
            </div>
            <span className="rounded-lg bg-[#28301C] px-3 py-1 font-mono text-xs text-[#9A7E3B]">
              GAIA ENGINE PROCESSING...
            </span>
          </div>
        )}

        {/* TAB 1: MAIN DASHBOARD & INTERACTIVE NASA MAP */}
        {activeTab === "dashboard" && (
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
            {/* Left Column (4 cols): Location Input, Presets, Previous Crop & Saved Farms */}
            <div className="space-y-6 lg:col-span-4">
              {/* Field Location & Telemetry Input Card */}
              <div className="rounded-xl border border-[#435133] bg-[#323D25] p-5 shadow-[0_10px_30px_-5px_rgba(0,0,0,0.4)]">
                <div className="flex items-center justify-between border-b border-[#435133] pb-3.5">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-[#9A7E3B]" />
                    <h2 className="text-base font-bold text-[#D2CF9A]">
                      {lang === "ar"
                        ? "تحديد موقع المزرعة وبيانات الأرض"
                        : "Farm Location & Field Parameters"}
                    </h2>
                  </div>
                  <span className="rounded-md bg-[#28301C] px-2 py-0.5 font-mono text-[10px] text-[#9FA37C]">
                    GPS / GIS
                  </span>
                </div>

                {/* Quick Regional Presets */}
                <div className="mt-4">
                  <label className="block text-xs font-semibold text-[#9FA37C] mb-2">
                    {lang === "ar"
                      ? "اختر منطقة زراعية سريعة أو حدد إحداثيات أرضك:"
                      : "Quick-Select Agricultural Zone or Enter Coordinates:"}
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {FARM_PRESETS.map((preset) => {
                      const isSelected =
                        Math.abs(Number(latInput) - preset.lat) < 0.02 &&
                        Math.abs(Number(lonInput) - preset.lon) < 0.02;
                      return (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => handleSelectPreset(preset.id)}
                          className={`rounded-lg border px-2.5 py-1.5 text-xs font-semibold transition-all ${
                            isSelected
                              ? "border-[#9A7E3B] bg-[#9A7E3B] text-[#28301C]"
                              : "border-[#435133] bg-[#28301C] text-[#D2CF9A] hover:border-[#9A7E3B]"
                          }`}
                        >
                          {lang === "ar" ? preset.nameAr : preset.nameEn}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Coordinate & Crop History Form */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleRunFieldAnalysis();
                  }}
                  className="mt-4 space-y-3.5"
                >
                  <div>
                    <label className="block text-xs font-semibold text-[#D2CF9A] mb-1">
                      {lang === "ar"
                        ? "اسم المزرعة / الحقل"
                        : "Farm / Parcel Name"}
                    </label>
                    <input
                      type="text"
                      value={farmNameInput}
                      onChange={(e) => setFarmNameInput(e.target.value)}
                      className="w-full rounded-lg border border-[#435133] bg-[#28301C] px-3 py-2 text-xs text-[#D2CF9A] focus:border-[#9A7E3B] focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3" dir="ltr">
                    <div>
                      <label className="block font-mono text-[11px] font-semibold text-[#9FA37C] mb-1">
                        LATITUDE (°N)
                      </label>
                      <input
                        type="number"
                        step="0.0001"
                        value={latInput}
                        onChange={(e) => setLatInput(e.target.value)}
                        className="w-full rounded-lg border border-[#435133] bg-[#28301C] px-3 py-2 font-mono text-xs text-[#D2CF9A] focus:border-[#9A7E3B] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-mono text-[11px] font-semibold text-[#9FA37C] mb-1">
                        LONGITUDE (°E)
                      </label>
                      <input
                        type="number"
                        step="0.0001"
                        value={lonInput}
                        onChange={(e) => setLonInput(e.target.value)}
                        className="w-full rounded-lg border border-[#435133] bg-[#28301C] px-3 py-2 font-mono text-xs text-[#D2CF9A] focus:border-[#9A7E3B] focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    <div>
                      <label className="block text-xs font-semibold text-[#D2CF9A] mb-1">
                        {lang === "ar"
                          ? "المحصول السابق (لتدوير المحاصيل)"
                          : "Previous Season Crop"}
                      </label>
                      <select
                        value={previousCropInput}
                        onChange={(e) => setPreviousCropInput(e.target.value)}
                        className="w-full rounded-lg border border-[#435133] bg-[#28301C] px-3 py-2 text-xs text-[#D2CF9A] focus:border-[#9A7E3B] focus:outline-none"
                      >
                        <option value="">
                          {lang === "ar"
                            ? "أرض بكر / بدون محصول سابق"
                            : "Fallow / No Previous Crop"}
                        </option>
                        {INITIAL_CROPS_SEED.map((c) => (
                          <option key={c.code} value={c.code}>
                            {lang === "ar"
                              ? `${c.nameAr} (${c.family})`
                              : `${c.nameEn} (${c.family})`}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#D2CF9A] mb-1">
                        {lang === "ar"
                          ? "المساحة (بالفدان)"
                          : "Area (Feddans)"}
                      </label>
                      <input
                        type="number"
                        min="1"
                        max="10000"
                        value={areaFeddansInput}
                        onChange={(e) => setAreaFeddansInput(e.target.value)}
                        className="w-full rounded-lg border border-[#435133] bg-[#28301C] px-3 py-2 font-mono text-xs text-[#D2CF9A] focus:border-[#9A7E3B] focus:outline-none"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isAnalyzing}
                    className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl bg-[#9A7E3B] px-5 py-3 text-sm font-extrabold text-[#28301C] shadow-lg transition-all hover:bg-[#b09145] disabled:opacity-60"
                  >
                    {isAnalyzing ? (
                      <RefreshCw className="h-4 w-4 animate-spin" />
                    ) : (
                      <Sparkles className="h-4 w-4" />
                    )}
                    <span>
                      {lang === "ar"
                        ? "تحليل الأرض ببيانات ناسا (Analyze Field)"
                        : "Analyze Field with NASA Telemetry"}
                    </span>
                  </button>
                </form>
              </div>

              {/* #1 Top Crop Decision Hero Card with Circular Suitability Gauge */}
              {topRecommendation && (
                <div className="rounded-xl border-2 border-[#9A7E3B] bg-[#323D25] p-5 shadow-[0_10px_30px_-5px_rgba(0,0,0,0.5)]">
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-[#9A7E3B]/25 border border-[#9A7E3B] px-3 py-0.5 text-xs font-bold text-[#D2CF9A]">
                      <Award className="h-3.5 w-3.5 text-[#9A7E3B]" />
                      {lang === "ar"
                        ? "القرار الزراعي الأنسب لأرضك"
                        : "Top Scientific Crop Match"}
                    </span>
                    <span className="font-mono text-xs text-[#9FA37C]">
                      {topRecommendation.family}
                    </span>
                  </div>

                  <div className="mt-4 flex items-center justify-between gap-4">
                    <div>
                      <h3 className="text-2xl font-extrabold text-[#D2CF9A]">
                        {lang === "ar"
                          ? topRecommendation.nameAr
                          : topRecommendation.nameEn}
                      </h3>
                      <p className="font-mono text-xs italic text-[#9FA37C]">
                        {topRecommendation.scientificName}
                      </p>
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        <span className="rounded-md bg-[#28301C] px-2 py-0.5 text-[11px] text-[#52B788]">
                          {lang === "ar"
                            ? `توافق الحرارة: ${topRecommendation.tempScore}%`
                            : `Temp Match: ${topRecommendation.tempScore}%`}
                        </span>
                        <span className="rounded-md bg-[#28301C] px-2 py-0.5 text-[11px] text-[#D2CF9A]">
                          {lang === "ar"
                            ? `توافق pH: ${topRecommendation.phScore}%`
                            : `pH Match: ${topRecommendation.phScore}%`}
                        </span>
                      </div>
                    </div>

                    {/* Circular Suitability Score Gauge */}
                    <div className="relative flex h-24 w-24 shrink-0 items-center justify-center">
                      <svg className="h-24 w-24 -rotate-90" viewBox="0 0 96 96">
                        <circle
                          cx="48"
                          cy="48"
                          r="40"
                          stroke="#28301C"
                          strokeWidth="8"
                          fill="none"
                        />
                        <circle
                          cx="48"
                          cy="48"
                          r="40"
                          stroke="#9A7E3B"
                          strokeWidth="8"
                          strokeDasharray={`${
                            (topRecommendation.suitabilityScore / 100) * 251.2
                          } 251.2`}
                          strokeLinecap="round"
                          fill="none"
                        />
                      </svg>
                      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                        <span className="font-mono text-lg font-extrabold text-[#D2CF9A]">
                          {topRecommendation.suitabilityScore}%
                        </span>
                        <span className="text-[9px] uppercase text-[#9FA37C]">
                          {lang === "ar" ? "الملاءمة" : "Suitability"}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Scientific Explainability Box */}
                  <div className="mt-4 space-y-1.5 rounded-xl border border-[#435133] bg-[#28301C] p-3 text-xs">
                    <div className="font-bold text-[#9A7E3B]">
                      {lang === "ar"
                        ? "التفسير العلمي للقرار (Explainability):"
                        : "Scientific Decision Explainability:"}
                    </div>
                    {(lang === "ar"
                      ? topRecommendation.reasonsAr
                      : topRecommendation.reasonsEn
                    ).map((reason, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-1.5 text-[#D2CF9A]/90 leading-relaxed"
                      >
                        <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#52B788]" />
                        <span>{reason}</span>
                      </div>
                    ))}
                  </div>

                  <div className="mt-3 flex gap-2">
                    <button
                      type="button"
                      onClick={() => setActiveTab("suitability")}
                      className="flex-1 rounded-lg border border-[#435133] bg-[#28301C] px-3 py-2 text-xs font-bold text-[#D2CF9A] hover:border-[#9A7E3B] transition-colors"
                    >
                      {lang === "ar"
                        ? "مقارنة كل المحاصيل (10)"
                        : "Compare All 10 Crops"}
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setChatPromptTrigger({
                          text:
                            lang === "ar"
                              ? `اشرح لي بالتفصيل لماذا يعتبر محصول (${topRecommendation.nameAr}) هو الأنسب لأرضي بنسبة ${topRecommendation.suitabilityScore}% وكيف أزرعه؟`
                              : `Explain in detail why ${topRecommendation.nameEn} scored ${topRecommendation.suitabilityScore}% for my land and how to cultivate it.`,
                          timestamp: Date.now(),
                        })
                      }
                      className="rounded-lg bg-[#9A7E3B]/25 border border-[#9A7E3B] px-3 py-2 text-xs font-bold text-[#D2CF9A] hover:bg-[#9A7E3B] hover:text-[#28301C] transition-colors"
                    >
                      {lang === "ar" ? "اسأل المساعد الذكي" : "Ask AI Advisor"}
                    </button>
                  </div>
                </div>
              )}

              {/* Saved Analyses History (Persisted in PostgreSQL) */}
              <div className="rounded-xl border border-[#435133] bg-[#323D25] p-5 shadow-[0_10px_30px_-5px_rgba(0,0,0,0.4)]">
                <div className="flex items-center justify-between border-b border-[#435133] pb-3">
                  <div className="flex items-center gap-2">
                    <History className="h-4 w-4 text-[#9A7E3B]" />
                    <h3 className="text-sm font-bold text-[#D2CF9A]">
                      {lang === "ar"
                        ? "سجل المزارع المحفوظة (PostgreSQL)"
                        : "Saved Field Reports (PostgreSQL)"}
                    </h3>
                  </div>
                  <span className="font-mono text-xs text-[#9FA37C]">
                    {savedAnalyses.length}
                  </span>
                </div>

                <div className="mt-3 space-y-2 max-h-60 overflow-y-auto">
                  {savedAnalyses.map((item) => {
                    const isCurrent = activeAnalysis?.id === item.id;
                    const bestCrop = item.recommendations?.[0];
                    return (
                      <div
                        key={item.id}
                        onClick={() => {
                          setActiveAnalysis(item);
                          setLatInput(String(item.latitude));
                          setLonInput(String(item.longitude));
                          setFarmNameInput(item.farmName);
                          setPreviousCropInput(item.previousCropCode || "");
                          setSelectedCropDetail(
                            item.recommendations?.[0] || null
                          );
                        }}
                        className={`flex cursor-pointer items-center justify-between rounded-lg border p-2.5 text-xs transition-all ${
                          isCurrent
                            ? "border-[#9A7E3B] bg-[#28301C]"
                            : "border-[#435133] bg-[#28301C]/50 hover:border-[#9A7E3B]/60"
                        }`}
                      >
                        <div>
                          <div className="font-bold text-[#D2CF9A]">
                            {item.farmName}
                          </div>
                          <div
                            dir="ltr"
                            className="font-mono text-[10px] text-[#9FA37C]"
                          >
                            {item.latitude.toFixed(3)}°N,{" "}
                            {item.longitude.toFixed(3)}°E • pH {item.soilPh}
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {bestCrop && (
                            <span className="rounded-md bg-[#9A7E3B]/20 border border-[#9A7E3B]/50 px-2 py-0.5 font-mono text-[11px] font-bold text-[#D2CF9A]">
                              {lang === "ar"
                                ? bestCrop.nameAr
                                : bestCrop.nameEn}{" "}
                              ({bestCrop.suitabilityScore}%)
                            </span>
                          )}
                          {savedAnalyses.length > 1 && (
                            <button
                              type="button"
                              onClick={(e) =>
                                handleDeleteSavedAnalysis(item.id, e)
                              }
                              className="rounded p-1 text-[#9FA37C] hover:bg-[#D9534F]/20 hover:text-[#D9534F]"
                              title="Delete report"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Right Column (8 cols): Interactive NASA Map + 3-Month Forecast + Rotation Preview + Alerts */}
            <div className="space-y-6 lg:col-span-8">
              {/* Interactive NASA GIBS & POWER Map */}
              <NasaInteractiveMap
                lat={activeAnalysis?.latitude ?? (Number(latInput) || 31.1107)}
                lon={activeAnalysis?.longitude ?? (Number(lonInput) || 30.9388)}
                farmName={activeAnalysis?.farmName ?? farmNameInput}
                ndviIndex={activeAnalysis?.ndviIndex ?? 0.68}
                avgTemp={activeAnalysis?.avgTemp3Mo ?? 21.4}
                soilMoistureRoot={activeAnalysis?.soilMoistureRoot ?? 61.5}
                soilPh={activeAnalysis?.soilPh ?? 7.25}
                dataSourceStatus={
                  activeAnalysis?.dataSourceStatus ?? "NASA_LIVE"
                }
                rawNasaPayload={activeAnalysis?.rawNasaPayload ?? {}}
                lang={lang}
                onSelectCoordinates={handleMapClickCoordinates}
              />

              {/* 3-Month Climate Change & Telemetry Projection (Point 1 & Point 4) */}
              {activeAnalysis && (
                <div className="rounded-xl border border-[#435133] bg-[#323D25] p-5 shadow-[0_10px_30px_-5px_rgba(0,0,0,0.4)]">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#435133] pb-3.5">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-5 w-5 text-[#9A7E3B]" />
                      <div>
                        <h3 className="text-base font-bold text-[#D2CF9A]">
                          {lang === "ar"
                            ? "توقعات المناخ والأمطار والحرارة للـ 3 أشهر القادمة (NASA POWER Climatology)"
                            : "3-Month Expected Temperature, Humidity & Rainfall Projection"}
                        </h3>
                        <p className="text-xs text-[#9FA37C]">
                          {lang === "ar"
                            ? "تحليل التغيرات المناخية الشهرية لـ 90 يوماً قدام بناءً على سجلات الأقمار الصناعية لوكالة ناسا"
                            : "90-day seasonal agroclimatology breakdown derived from NASA POWER satellite records"}
                        </p>
                      </div>
                    </div>
                    <span className="rounded-lg bg-[#28301C] px-2.5 py-1 font-mono text-xs text-[#9A7E3B]">
                      T2M • RH2M • PRECTOTCORR
                    </span>
                  </div>

                  <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-3">
                    {activeAnalysis.forecast3Months.map((m) => (
                      <div
                        key={m.monthIndex}
                        className="flex flex-col justify-between rounded-xl border border-[#435133] bg-[#28301C] p-4"
                      >
                        <div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-extrabold text-[#D2CF9A]">
                              {lang === "ar"
                                ? `الشهر ${m.monthIndex}: ${m.monthNameAr}`
                                : `Month ${m.monthIndex}: ${m.monthNameEn}`}
                            </span>
                            <span className="rounded-md bg-[#323D25] px-2 py-0.5 font-mono text-xs font-bold text-[#9A7E3B]">
                              {m.tempAvg}°C
                            </span>
                          </div>

                          {/* Metrics bars */}
                          <div className="mt-3 space-y-2.5 text-xs">
                            <div>
                              <div className="flex justify-between text-[11px] text-[#9FA37C]">
                                <span>
                                  {lang === "ar"
                                    ? "مدى الحرارة (صغرى – عظمى)"
                                    : "Temp Range (Min–Max)"}
                                </span>
                                <span className="font-mono text-[#D2CF9A]">
                                  {m.tempMin}°C – {m.tempMax}°C
                                </span>
                              </div>
                              <div className="mt-1 h-1.5 w-full rounded-full bg-[#323D25]">
                                <div
                                  className="h-full rounded-full bg-[#E09F3E]"
                                  style={{
                                    width: `${Math.min(
                                      100,
                                      (m.tempMax / 42) * 100
                                    )}%`,
                                  }}
                                />
                              </div>
                            </div>

                            <div>
                              <div className="flex justify-between text-[11px] text-[#9FA37C]">
                                <span>
                                  {lang === "ar"
                                    ? "الرطوبة الجوية (RH2M)"
                                    : "Relative Humidity (RH2M)"}
                                </span>
                                <span className="font-mono text-[#48CAE4]">
                                  {m.humidityAvg}%
                                </span>
                              </div>
                              <div className="mt-1 h-1.5 w-full rounded-full bg-[#323D25]">
                                <div
                                  className="h-full rounded-full bg-[#48CAE4]"
                                  style={{ width: `${m.humidityAvg}%` }}
                                />
                              </div>
                            </div>

                            <div className="flex items-center justify-between border-t border-[#435133]/70 pt-2">
                              <span className="text-[11px] text-[#9FA37C]">
                                {lang === "ar"
                                  ? "الأمطار المتوقعة:"
                                  : "Expected Rain:"}
                              </span>
                              <span className="font-mono text-xs font-bold text-[#52B788]">
                                {m.precipMm} mm
                              </span>
                            </div>

                            <div className="flex items-center justify-between">
                              <span className="text-[11px] text-[#9FA37C]">
                                {lang === "ar"
                                  ? "رطوبة الجذور:"
                                  : "Root Wetness:"}
                              </span>
                              <span className="font-mono text-xs text-[#D2CF9A]">
                                {m.soilMoistureRoot}%
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="mt-3 rounded-lg bg-[#323D25] p-2 text-[11px] text-[#D2CF9A]/90 leading-relaxed">
                          {lang === "ar" ? m.riskNoteAr : m.riskNoteEn}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Quick 3-Season Crop Rotation Strip & Early Warning Alerts */}
              {activeAnalysis && (
                <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
                  {/* 3-Season Rotation Summary Card */}
                  <div className="rounded-xl border border-[#435133] bg-[#323D25] p-5 shadow-[0_10px_30px_-5px_rgba(0,0,0,0.4)]">
                    <div className="flex items-center justify-between border-b border-[#435133] pb-3">
                      <div className="flex items-center gap-2">
                        <ArrowLeftRight className="h-5 w-5 text-[#9A7E3B]" />
                        <h3 className="text-sm font-bold text-[#D2CF9A]">
                          {lang === "ar"
                            ? "خطة تدوير المحاصيل المقترحة (3 مواسم)"
                            : "Recommended 3-Season Crop Rotation"}
                        </h3>
                      </div>
                      <button
                        type="button"
                        onClick={() => setActiveTab("rotation")}
                        className="text-xs font-bold text-[#9A7E3B] hover:underline"
                      >
                        {lang === "ar" ? "عرض التفاصيل ←" : "Full Timeline →"}
                      </button>
                    </div>

                    <div className="mt-3 space-y-2.5">
                      {activeAnalysis.rotationPlan.map((step) => (
                        <div
                          key={step.seasonNumber}
                          className="rounded-xl border border-[#435133] bg-[#28301C] p-3"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#9A7E3B] font-mono text-xs font-extrabold text-[#28301C]">
                                {step.seasonNumber}
                              </span>
                              <div>
                                <div className="text-xs font-bold text-[#D2CF9A]">
                                  {lang === "ar"
                                    ? step.cropNameAr
                                    : step.cropNameEn}{" "}
                                  <span className="font-normal text-[#9FA37C]">
                                    ({step.family})
                                  </span>
                                </div>
                                <div className="text-[10px] text-[#9FA37C]">
                                  {lang === "ar"
                                    ? step.seasonLabelAr
                                    : step.seasonLabelEn}
                                </div>
                              </div>
                            </div>

                            <span
                              className={`rounded-md px-2 py-0.5 text-[10px] font-bold ${
                                step.nitrogenBadge === "fixer"
                                  ? "bg-[#52B788]/20 text-[#52B788]"
                                  : "bg-[#9A7E3B]/20 text-[#D2CF9A]"
                              }`}
                            >
                              {lang === "ar"
                                ? step.nitrogenRoleAr
                                : step.nitrogenRoleEn}
                            </span>
                          </div>
                          <p className="mt-2 text-[11px] text-[#D2CF9A]/85 leading-relaxed">
                            {lang === "ar"
                              ? step.rationaleAr
                              : step.rationaleEn}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Proactive Climate & Soil Alerts Card */}
                  <div className="rounded-xl border border-[#435133] bg-[#323D25] p-5 shadow-[0_10px_30px_-5px_rgba(0,0,0,0.4)]">
                    <div className="flex items-center justify-between border-b border-[#435133] pb-3">
                      <div className="flex items-center gap-2">
                        <ShieldAlert className="h-5 w-5 text-[#9A7E3B]" />
                        <h3 className="text-sm font-bold text-[#D2CF9A]">
                          {lang === "ar"
                            ? "نظام الإنذار المبكر والتوصيات التشغيلية"
                            : "Early Warning System & Actionable Alerts"}
                        </h3>
                      </div>
                      <span className="font-mono text-[10px] text-[#9FA37C]">
                        LIVE TELEMETRY
                      </span>
                    </div>

                    <div className="mt-3 space-y-2.5">
                      {activeAnalysis.climateAlerts.map((alert) => (
                        <div
                          key={alert.id}
                          className={`rounded-xl border p-3 ${
                            alert.severity === "critical"
                              ? "border-[#D9534F]/60 bg-[#D9534F]/10"
                              : alert.severity === "warning"
                              ? "border-[#E09F3E]/60 bg-[#E09F3E]/10"
                              : "border-[#52B788]/50 bg-[#28301C]"
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-[#D2CF9A]">
                              {lang === "ar" ? alert.titleAr : alert.titleEn}
                            </span>
                            <span className="rounded bg-[#28301C] px-1.5 py-0.5 font-mono text-[10px] text-[#9A7E3B]">
                              {alert.parameterCode}
                            </span>
                          </div>
                          <p className="mt-1 text-[11px] text-[#D2CF9A]/85">
                            {lang === "ar" ? alert.messageAr : alert.messageEn}
                          </p>
                          <div className="mt-2 flex items-start gap-1.5 border-t border-[#435133]/60 pt-1.5 text-[11px] font-semibold text-[#52B788]">
                            <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                            <span>
                              {lang === "ar" ? alert.actionAr : alert.actionEn}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: SCIENTIFIC CROP SUITABILITY MATRIX (ALL 10 CROPS) */}
        {activeTab === "suitability" && activeAnalysis && (
          <div className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-[#435133] bg-[#323D25] p-5">
              <div>
                <h2 className="text-lg font-extrabold text-[#D2CF9A]">
                  {lang === "ar"
                    ? `تقرير ملاءمة المحاصيل الشامل لمزرعة: ${activeAnalysis.farmName}`
                    : `Comprehensive Crop Suitability Report: ${activeAnalysis.farmName}`}
                </h2>
                <p className="text-xs text-[#9FA37C]">
                  {lang === "ar"
                    ? `مرتبة تنازلياً حسب خوارزمية الأوزان المرجحة (الحرارة T2M = ${activeAnalysis.avgTemp3Mo}°C | قلوية التربة pH = ${activeAnalysis.soilPh} | الرطوبة RH2M = ${activeAnalysis.relativeHumidity}% | المحصول السابق = ${
                        activeAnalysis.previousCropCode || "لا يوجد"
                      })`
                    : `Ranked by Weighted Penalty Algorithm (T2M = ${activeAnalysis.avgTemp3Mo}°C | Soil pH = ${activeAnalysis.soilPh} | Humidity RH2M = ${activeAnalysis.relativeHumidity}%)`}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-[#9FA37C]">
                  {lang === "ar"
                    ? "تغيير المحصول السابق للمقارنة الفورية:"
                    : "Change Previous Crop to Recalculate:"}
                </span>
                <select
                  value={previousCropInput}
                  onChange={(e) => {
                    const newPrev = e.target.value;
                    setPreviousCropInput(newPrev);
                    handleRunFieldAnalysis({
                      lat: activeAnalysis.latitude,
                      lon: activeAnalysis.longitude,
                      farmName: activeAnalysis.farmName,
                      previousCrop: newPrev,
                    });
                  }}
                  className="rounded-lg border border-[#9A7E3B] bg-[#28301C] px-3 py-1.5 text-xs font-bold text-[#D2CF9A]"
                >
                  <option value="">
                    {lang === "ar" ? "بدون محصول سابق" : "None"}
                  </option>
                  {INITIAL_CROPS_SEED.map((c) => (
                    <option key={c.code} value={c.code}>
                      {lang === "ar" ? c.nameAr : c.nameEn}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
              {activeAnalysis.recommendations.map((crop, idx) => {
                const isTop3 = idx < 3;
                return (
                  <div
                    key={crop.cropCode}
                    onClick={() => setSelectedCropDetail(crop)}
                    className={`cursor-pointer rounded-xl border p-5 transition-all ${
                      selectedCropDetail?.cropCode === crop.cropCode
                        ? "border-2 border-[#9A7E3B] bg-[#323D25] shadow-xl"
                        : "border-[#435133] bg-[#323D25]/90 hover:border-[#9A7E3B]/60"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span
                            className={`flex h-6 w-6 items-center justify-center rounded-full font-mono text-xs font-extrabold ${
                              isTop3
                                ? "bg-[#9A7E3B] text-[#28301C]"
                                : "bg-[#28301C] text-[#9FA37C]"
                            }`}
                          >
                            #{idx + 1}
                          </span>
                          <h3 className="text-base font-extrabold text-[#D2CF9A]">
                            {lang === "ar" ? crop.nameAr : crop.nameEn}
                          </h3>
                        </div>
                        <p className="mt-0.5 text-[11px] text-[#9FA37C]">
                          {lang === "ar" ? crop.familyAr : crop.family} •{" "}
                          {crop.growthDurationDays}{" "}
                          {lang === "ar" ? "يوماً" : "days"}
                        </p>
                      </div>

                      <div className="text-left" dir="ltr">
                        <div
                          className={`font-mono text-2xl font-extrabold ${
                            crop.suitabilityScore >= 82
                              ? "text-[#52B788]"
                              : crop.suitabilityScore >= 65
                              ? "text-[#E09F3E]"
                              : "text-[#D9534F]"
                          }`}
                        >
                          {crop.suitabilityScore}%
                        </div>
                        <div className="text-[10px] font-mono text-[#9FA37C]">
                          SUITABILITY
                        </div>
                      </div>
                    </div>

                    {/* Sub-scores breakdown */}
                    <div className="mt-4 grid grid-cols-3 gap-2 rounded-lg bg-[#28301C] p-2.5 text-center font-mono text-[11px]">
                      <div>
                        <div className="text-[10px] text-[#9FA37C]">
                          T2M Match
                        </div>
                        <div className="font-bold text-[#D2CF9A]">
                          {crop.tempScore}%
                        </div>
                      </div>
                      <div className="border-x border-[#435133]">
                        <div className="text-[10px] text-[#9FA37C]">
                          pH Match
                        </div>
                        <div className="font-bold text-[#D2CF9A]">
                          {crop.phScore}%
                        </div>
                      </div>
                      <div>
                        <div className="text-[10px] text-[#9FA37C]">
                          Rotation
                        </div>
                        <div
                          className={`font-bold ${
                            crop.rotationBonus > 0
                              ? "text-[#52B788]"
                              : crop.rotationBonus < 0
                              ? "text-[#D9534F]"
                              : "text-[#D2CF9A]"
                          }`}
                        >
                          {crop.rotationBonus > 0
                            ? `+${crop.rotationBonus}%`
                            : `${crop.rotationBonus}%`}
                        </div>
                      </div>
                    </div>

                    {/* Explainability bullets */}
                    <div className="mt-3 space-y-1.5 text-xs">
                      {(lang === "ar" ? crop.reasonsAr : crop.reasonsEn)
                        .slice(0, 2)
                        .map((r, rIdx) => (
                          <div
                            key={rIdx}
                            className="flex items-start gap-1.5 text-[#D2CF9A]/90"
                          >
                            <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#52B788]" />
                            <span>{r}</span>
                          </div>
                        ))}
                      {(lang === "ar" ? crop.warningsAr : crop.warningsEn).map(
                        (w, wIdx) => (
                          <div
                            key={wIdx}
                            className="flex items-start gap-1.5 text-[#E09F3E]"
                          >
                            <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                            <span>{w}</span>
                          </div>
                        )
                      )}
                    </div>

                    <div className="mt-4 flex items-center justify-between border-t border-[#435133] pt-3 text-[11px]">
                      <span className="font-mono text-[#9FA37C]">
                        NPK:{" "}
                        {crop.nutrientsNpk.n === "fixer"
                          ? "N-Fixer (+N)"
                          : `N:${crop.nutrientsNpk.n}`}
                      </span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setChatPromptTrigger({
                            text:
                              lang === "ar"
                                ? `ما هو تقييمك لمحصول (${crop.nameAr}) في أرضي؟ وكيف أحقق أعلى إنتاجية منه؟`
                                : `Evaluate ${crop.nameEn} for my field and explain how to maximize its yield.`,
                            timestamp: Date.now(),
                          });
                        }}
                        className="font-bold text-[#9A7E3B] hover:underline"
                      >
                        {lang === "ar"
                          ? "اسأل خبير GAIA ←"
                          : "Ask GAIA Advisor →"}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 3: MULTI-SEASON CROP ROTATION PLANNER */}
        {activeTab === "rotation" && activeAnalysis && (
          <div className="space-y-6">
            <div className="rounded-xl border border-[#435133] bg-[#323D25] p-6">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#435133] pb-4">
                <div>
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-[#9A7E3B]/20 border border-[#9A7E3B] px-3 py-0.5 text-xs font-bold text-[#D2CF9A]">
                    <Sprout className="h-3.5 w-3.5 text-[#9A7E3B]" />
                    {lang === "ar"
                      ? "الميزة التنافسية لمشروع GAIA — محرك تدوير المحاصيل"
                      : "GAIA Competitive Edge — Multi-Season Crop Rotation Engine"}
                  </span>
                  <h2 className="mt-2 text-xl font-extrabold text-[#D2CF9A]">
                    {lang === "ar"
                      ? "المخطط الزمني لتدوير المحاصيل وموازنة النيتروجين (3 مواسم)"
                      : "3-Season Crop Rotation & Soil Nitrogen Balance Timeline"}
                  </h2>
                  <p className="mt-1 text-xs text-[#9FA37C]">
                    {lang === "ar"
                      ? "يقوم النظام بمنع تكرار نفس العائلة النباتية، ويناوب بين المحاصيل الشرهة للنيتروجين والمحاصيل البقولية المثبتة للنيتروجين مع تنويع عمق الجذور."
                      : "Automatically prevents back-to-back planting of the same botanical family, alternates N-fixers with heavy feeders, and varies root depth."}
                  </p>
                </div>

                <div className="rounded-xl border border-[#435133] bg-[#28301C] p-3 text-xs">
                  <div className="text-[#9FA37C]">
                    {lang === "ar"
                      ? "المحصول المزروع سابقاً في الأرض:"
                      : "Previous Crop in Field:"}
                  </div>
                  <div className="mt-1 font-bold text-[#9A7E3B]">
                    {INITIAL_CROPS_SEED.find(
                      (c) => c.code === activeAnalysis.previousCropCode
                    )?.[lang === "ar" ? "nameAr" : "nameEn"] ??
                      (lang === "ar" ? "أرض بكر" : "Fallow")}
                  </div>
                </div>
              </div>

              {/* 3-Season Interactive Cards */}
              <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
                {activeAnalysis.rotationPlan.map((step) => (
                  <div
                    key={step.seasonNumber}
                    className="relative flex flex-col justify-between rounded-2xl border-2 border-[#9A7E3B]/70 bg-[#28301C] p-5 shadow-lg"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="rounded-lg bg-[#9A7E3B] px-3 py-1 text-xs font-extrabold text-[#28301C]">
                          {lang === "ar"
                            ? step.seasonLabelAr
                            : step.seasonLabelEn}
                        </span>
                        <span className="font-mono text-sm font-extrabold text-[#52B788]">
                          {step.suitabilityScore}%
                        </span>
                      </div>

                      <h3 className="mt-4 text-2xl font-extrabold text-[#D2CF9A]">
                        {lang === "ar" ? step.cropNameAr : step.cropNameEn}
                      </h3>
                      <p className="text-xs text-[#9FA37C]">
                        {lang === "ar" ? step.familyAr : step.family}
                      </p>

                      <div className="mt-4 space-y-2 rounded-xl border border-[#435133] bg-[#323D25] p-3 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="text-[#9FA37C]">
                            {lang === "ar"
                              ? "ميزان النيتروجين:"
                              : "Nitrogen Role:"}
                          </span>
                          <span
                            className={`font-bold ${
                              step.nitrogenBadge === "fixer"
                                ? "text-[#52B788]"
                                : "text-[#E09F3E]"
                            }`}
                          >
                            {lang === "ar"
                              ? step.nitrogenRoleAr
                              : step.nitrogenRoleEn}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-[#9FA37C]">
                            {lang === "ar"
                              ? "عمق انتشار الجذور:"
                              : "Root Architecture:"}
                          </span>
                          <span className="font-mono font-bold text-[#D2CF9A]">
                            {step.rootDepth.toUpperCase()}
                          </span>
                        </div>
                      </div>

                      <div className="mt-4">
                        <div className="text-xs font-bold text-[#9A7E3B] mb-1">
                          {lang === "ar"
                            ? "سبب الاختيار في الدورة الزراعية:"
                            : "Rotation Logic & Agronomic Benefit:"}
                        </div>
                        <p className="text-xs leading-relaxed text-[#D2CF9A]/90">
                          {lang === "ar" ? step.rationaleAr : step.rationaleEn}
                        </p>
                      </div>
                    </div>

                    <div className="mt-5 border-t border-[#435133] pt-3 flex items-center justify-between text-[11px] text-[#9FA37C]">
                      <span>
                        {lang === "ar"
                          ? "يكسر دورة الآفات الفطرية والحشرية"
                          : "Breaks soil-borne pathogen cycle"}
                      </span>
                      <CheckCircle2 className="h-4 w-4 text-[#52B788]" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: CROP KNOWLEDGE BASE & SUITABILITY ALGORITHM */}
        {activeTab === "knowledge" && (
          <div className="space-y-6">
            <div className="rounded-xl border border-[#435133] bg-[#323D25] p-6">
              <div className="flex items-center gap-2.5 border-b border-[#435133] pb-4">
                <Info className="h-5 w-5 text-[#9A7E3B]" />
                <div>
                  <h2 className="text-lg font-extrabold text-[#D2CF9A]">
                    {lang === "ar"
                      ? "قاعدة المعرفة البيولوجية للمحاصيل والنمذجة الرياضية (Crop Intelligence DB)"
                      : "Biological Crop Knowledge Base & Mathematical Suitability Model"}
                  </h2>
                  <p className="text-xs text-[#9FA37C]">
                    {lang === "ar"
                      ? "المرجع العلمي المخزن في قاعدة بيانات PostgreSQL لمقارنة بيانات NASA POWER و SoilGrids باحتياجات كل نبات"
                      : "PostgreSQL reference table used to evaluate NASA POWER & SoilGrids parameters against biological thresholds"}
                  </p>
                </div>
              </div>

              <div className="mt-4 overflow-x-auto">
                <table className="w-full text-right text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-[#435133] bg-[#28301C] text-[#9FA37C]">
                      <th className="p-3">
                        {lang === "ar" ? "المحصول" : "Crop"}
                      </th>
                      <th className="p-3">
                        {lang === "ar" ? "العائلة النباتية" : "Botanical Family"}
                      </th>
                      <th className="p-3" dir="ltr">
                        Temp Range (°C)
                      </th>
                      <th className="p-3" dir="ltr">
                        Soil pH Range
                      </th>
                      <th className="p-3">
                        {lang === "ar"
                          ? "احتياج النيتروجين (NPK)"
                          : "Nitrogen Role"}
                      </th>
                      <th className="p-3">
                        {lang === "ar" ? "عمق الجذور" : "Root Depth"}
                      </th>
                      <th className="p-3">
                        {lang === "ar" ? "تحمل الملوحة" : "Salinity Tol."}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#435133]">
                    {INITIAL_CROPS_SEED.map((c) => (
                      <tr
                        key={c.code}
                        className="hover:bg-[#28301C]/60 transition-colors"
                      >
                        <td className="p-3 font-bold text-[#D2CF9A]">
                          {lang === "ar" ? c.nameAr : c.nameEn}{" "}
                          <span className="block font-mono text-[10px] font-normal italic text-[#9FA37C]">
                            {c.scientificName}
                          </span>
                        </td>
                        <td className="p-3 text-[#D2CF9A]">
                          {lang === "ar" ? c.familyAr : c.family}
                        </td>
                        <td className="p-3 font-mono text-[#E09F3E]" dir="ltr">
                          {c.tempMin} – {c.tempMax}°C (Opt: {c.tempOpt}°C)
                        </td>
                        <td className="p-3 font-mono text-[#52B788]" dir="ltr">
                          {c.phMin} – {c.phMax} (Opt: {c.phOpt})
                        </td>
                        <td className="p-3">
                          <span
                            className={`rounded-md px-2 py-0.5 font-mono text-[11px] font-bold ${
                              c.nutrientsNpk.n === "fixer"
                                ? "bg-[#52B788]/20 text-[#52B788]"
                                : "bg-[#9A7E3B]/20 text-[#D2CF9A]"
                            }`}
                          >
                            {c.nutrientsNpk.n === "fixer"
                              ? `+${c.nutrientsNpk.nitrogen_delta_kg_ha} kg/ha (Fixer)`
                              : `${c.nutrientsNpk.nitrogen_delta_kg_ha} kg/ha (${c.nutrientsNpk.n})`}
                          </span>
                        </td>
                        <td className="p-3 font-mono text-[#D2CF9A]">
                          {c.rootDepth}
                        </td>
                        <td className="p-3 font-mono text-[#D2CF9A]">
                          {c.salinityTolerance}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Optional Floating Context-Aware AI Chatbot (Point 5) */}
      <GaiaChatbotDrawer
        activeAnalysis={
          activeAnalysis as unknown as ActiveAnalysisForChat | null
        }
        lang={lang}
        externalPromptTrigger={chatPromptTrigger}
      />
    </div>
  );
}
