import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Cairo, Space_Grotesk, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-cairo",
});

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  weight: ["500", "600", "700"],
  variable: "--font-space",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "700"],
  variable: "--font-mono",
});

export const metadata: Metadata = {
  title: "GAIA | نظام دعم القرار الزراعي وتدوير المحاصيل ببيانات ناسا",
  description:
    "NASA Space Apps Challenge 2026 — Adapting Farms with NASA Data (NASA POWER, NASA GIBS NDVI, ISRIC SoilGrids, Crop Suitability & 3-Season Rotation Engine)",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="ar"
      dir="rtl"
      className={`${cairo.variable} ${spaceGrotesk.variable} ${jetbrainsMono.variable}`}
    >
      <body
        style={{ fontFamily: "var(--font-cairo), var(--font-space), sans-serif" }}
        className="min-h-screen bg-[#28301C] text-[#D2CF9A] antialiased selection:bg-[#9A7E3B] selection:text-[#28301C]"
      >
        {children}
      </body>
    </html>
  );
}
